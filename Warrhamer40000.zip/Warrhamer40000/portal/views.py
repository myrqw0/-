from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import TemplateView, ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.urls import reverse_lazy, reverse
from django.http import HttpResponseRedirect
from django.db.models import Q
from django.utils import timezone
from .models import *
from .forms import *

# Домашняя страница
class HomeView(TemplateView):
    template_name = 'portal/home.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['announcements'] = Announcement.objects.filter(is_active=True)[:5]
        context['events'] = Event.objects.filter(date__gte=timezone.now())[:5]
        context['materials'] = Material.objects.all()[:5]

        # Данные для виджетов дашборда
        if self.request.user.is_authenticated:
            context['user_grades'] = Grade.objects.filter(student=self.request.user).order_by('-date')[:5]
        else:
            context['user_grades'] = []

        context['recent_threads'] = ForumThread.objects.all().order_by('-created_at')[:5]

        return context

# Аутентификация
class LoginView(LoginView):
    template_name = 'portal/login.html'
    redirect_authenticated_user = True

class LogoutView(LogoutView):
    next_page = 'home'

class RegisterView(CreateView):
    model = User
    form_class = UserCreationForm
    template_name = 'portal/register.html'
    success_url = reverse_lazy('login')

    def form_valid(self, form):
        response = super().form_valid(form)
        UserRole.objects.create(user=self.object)
        UserProfile.objects.create(user=self.object)
        messages.success(self.request, 'Регистрация успешна! Теперь войдите в систему.')
        return response

# Профиль пользователя
class ProfileView(LoginRequiredMixin, UpdateView):
    model = UserProfile
    form_class = ProfileForm
    template_name = 'portal/profile.html'
    success_url = reverse_lazy('profile')

    def get_object(self):
        return self.request.user.userprofile

    def form_valid(self, form):
        messages.success(self.request, 'Профиль обновлен.')
        return super().form_valid(form)

# Форум
class ForumView(ListView):
    model = ForumThread
    template_name = 'portal/forum.html'
    context_object_name = 'threads'
    paginate_by = 20

class ForumThreadView(DetailView):
    model = ForumThread
    template_name = 'portal/forum_thread.html'
    context_object_name = 'thread'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['posts'] = self.object.posts.all()
        return context

class CreateForumThreadView(LoginRequiredMixin, CreateView):
    model = ForumThread
    form_class = ForumThreadForm
    template_name = 'portal/create_thread.html'
    success_url = reverse_lazy('forum')

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

class CreateForumPostView(LoginRequiredMixin, CreateView):
    model = ForumPost
    form_class = ForumPostForm
    template_name = 'portal/create_post.html'

    def form_valid(self, form):
        form.instance.author = self.request.user
        form.instance.thread = get_object_or_404(ForumThread, pk=self.kwargs['pk'])
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('forum_thread', kwargs={'pk': self.kwargs['pk']})

# Электронный дневник
class DiaryView(LoginRequiredMixin, ListView):
    model = Grade
    template_name = 'portal/diary.html'
    context_object_name = 'grades'

    def get_queryset(self):
        return Grade.objects.filter(student=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        grades = self.get_queryset()

        # Получение уникальных предметов
        context['subjects'] = sorted(set(grade.subject for grade in grades))

        if grades:
            total_grades = sum(grade.grade for grade in grades)
            context['average_grade'] = total_grades / len(grades)
            context['excellent_count'] = sum(1 for grade in grades if grade.grade >= 9)
            context['good_count'] = sum(1 for grade in grades if 7 <= grade.grade < 9)
            context['satisfactory_count'] = sum(1 for grade in grades if 4 <= grade.grade < 7)
            context['poor_count'] = sum(1 for grade in grades if grade.grade < 4)

            # Данные для графика
            context['chart_data'] = {
                'labels': ['Отлично (9-12)', 'Хорошо (7-8)', 'Удовлетворительно (4-6)', 'Неудовлетворительно (1-3)'],
                'data': [
                    context['excellent_count'],
                    context['good_count'],
                    context['satisfactory_count'],
                    context['poor_count']
                ],
                'colors': ['#28a745', '#ffc107', '#fd7e14', '#dc3545']
            }
        else:
            context['average_grade'] = 0
            context['excellent_count'] = 0
            context['good_count'] = 0
            context['satisfactory_count'] = 0
            context['poor_count'] = 0
            context['chart_data'] = {
                'labels': ['Отлично (9-12)', 'Хорошо (7-8)', 'Удовлетворительно (4-6)', 'Неудовлетворительно (1-3)'],
                'data': [0, 0, 0, 0],
                'colors': ['#28a745', '#ffc107', '#fd7e14', '#dc3545']
            }
        return context

class AddGradeView(UserPassesTestMixin, CreateView):
    model = Grade
    form_class = GradeForm
    template_name = 'portal/add_grade.html'
    success_url = reverse_lazy('diary')

    def test_func(self):
        return self.request.user.userrole.role in ['admin', 'moderator']

    def form_valid(self, form):
        form.instance.teacher = self.request.user
        return super().form_valid(form)

# События
class EventsView(ListView):
    model = Event
    template_name = 'portal/events.html'
    context_object_name = 'events'
    paginate_by = 10

class CalendarView(TemplateView):
    template_name = 'portal/calendar.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['events'] = Event.objects.all()
        return context

class CreateEventView(UserPassesTestMixin, CreateView):
    model = Event
    form_class = EventForm
    template_name = 'portal/create_event.html'
    success_url = reverse_lazy('events')

    def test_func(self):
        return self.request.user.userrole.role in ['admin', 'moderator']

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

# Опросы
class SurveysView(ListView):
    model = Survey
    template_name = 'portal/surveys.html'
    context_object_name = 'surveys'
    paginate_by = 10

class SurveyDetailView(DetailView):
    model = Survey
    template_name = 'portal/survey_detail.html'
    context_object_name = 'survey'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['questions'] = self.object.questions.all()
        context['has_responded'] = SurveyResponse.objects.filter(
            survey=self.object, user=self.request.user
        ).exists() if self.request.user.is_authenticated else False
        return context

class TakeSurveyView(LoginRequiredMixin, TemplateView):
    template_name = 'portal/take_survey.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        survey = get_object_or_404(Survey, pk=self.kwargs['pk'])
        context['survey'] = survey
        context['questions'] = survey.questions.all()
        return context

    def post(self, request, *args, **kwargs):
        survey = get_object_or_404(Survey, pk=self.kwargs['pk'])
        if SurveyResponse.objects.filter(survey=survey, user=request.user).exists():
            messages.error(request, 'Вы уже прошли этот опрос.')
            return redirect('survey_detail', pk=survey.pk)

        response = SurveyResponse.objects.create(survey=survey, user=request.user)

        for question in survey.questions.all():
            answer_text = request.POST.get(f'question_{question.id}', '')
            answer = SurveyAnswer.objects.create(
                response=response,
                question=question,
                answer_text=answer_text
            )
            if question.question_type in ['choice', 'multiple']:
                selected_choices = request.POST.getlist(f'question_{question.id}_choices')
                answer.selected_choices.set(selected_choices)

        messages.success(request, 'Опрос пройден успешно!')
        return redirect('survey_detail', pk=survey.pk)

class CreateSurveyView(UserPassesTestMixin, CreateView):
    model = Survey
    form_class = SurveyForm
    template_name = 'portal/create_survey.html'
    success_url = reverse_lazy('surveys')

    def test_func(self):
        return self.request.user.userrole.role in ['admin', 'moderator']

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

# Голосования
class VotingsView(ListView):
    model = Voting
    template_name = 'portal/votings.html'
    context_object_name = 'votings'
    paginate_by = 10

class VotingDetailView(DetailView):
    model = Voting
    template_name = 'portal/voting_detail.html'
    context_object_name = 'voting'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['options'] = self.object.options.all()
        context['has_voted'] = Vote.objects.filter(
            voting=self.object, user=self.request.user
        ).exists() if self.request.user.is_authenticated else False
        context['votes'] = Vote.objects.filter(voting=self.object)
        return context

class VoteView(LoginRequiredMixin, CreateView):
    model = Vote
    form_class = VoteForm
    template_name = 'portal/vote.html'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['voting'] = get_object_or_404(Voting, pk=self.kwargs['pk'])
        return kwargs

    def form_valid(self, form):
        voting = get_object_or_404(Voting, pk=self.kwargs['pk'])
        if Vote.objects.filter(voting=voting, user=self.request.user).exists():
            messages.error(self.request, 'Вы уже голосовали в этом голосовании.')
            return redirect('voting_detail', pk=voting.pk)

        form.instance.voting = voting
        form.instance.user = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('voting_detail', kwargs={'pk': self.kwargs['pk']})

class CreateVotingView(UserPassesTestMixin, CreateView):
    model = Voting
    form_class = VotingForm
    template_name = 'portal/create_voting.html'
    success_url = reverse_lazy('votings')

    def test_func(self):
        return self.request.user.userrole.role in ['admin', 'moderator']

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

# Объявления
class AnnouncementsView(ListView):
    model = Announcement
    template_name = 'portal/announcements.html'
    context_object_name = 'announcements'
    paginate_by = 10

class CreateAnnouncementView(UserPassesTestMixin, CreateView):
    model = Announcement
    form_class = AnnouncementForm
    template_name = 'portal/create_announcement.html'
    success_url = reverse_lazy('announcements')

    def test_func(self):
        return self.request.user.userrole.role in ['admin', 'moderator']

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

# Материалы
class MaterialsView(ListView):
    model = Material
    template_name = 'portal/materials.html'
    context_object_name = 'materials'
    paginate_by = 10

class CreateMaterialView(LoginRequiredMixin, CreateView):
    model = Material
    form_class = MaterialForm
    template_name = 'portal/create_material.html'
    success_url = reverse_lazy('materials')

    def form_valid(self, form):
        form.instance.uploaded_by = self.request.user
        return super().form_valid(form)

# Портфолио
class PortfolioView(ListView):
    model = Portfolio
    template_name = 'portal/portfolio.html'
    context_object_name = 'portfolio_items'
    paginate_by = 10

    def get_queryset(self):
        return Portfolio.objects.filter(user=self.request.user) if self.request.user.is_authenticated else Portfolio.objects.none()

class CreatePortfolioView(LoginRequiredMixin, CreateView):
    model = Portfolio
    form_class = PortfolioForm
    template_name = 'portal/create_portfolio.html'
    success_url = reverse_lazy('portfolio')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

# Галерея
class GalleryView(ListView):
    model = GalleryItem
    template_name = 'portal/gallery.html'
    context_object_name = 'gallery_items'
    paginate_by = 20

    def get_queryset(self):
        return GalleryItem.objects.filter(approved=True)

class CreateGalleryItemView(LoginRequiredMixin, CreateView):
    model = GalleryItem
    form_class = GalleryItemForm
    template_name = 'portal/create_gallery_item.html'
    success_url = reverse_lazy('gallery')

    def form_valid(self, form):
        form.instance.uploaded_by = self.request.user
        return super().form_valid(form)



# Tasks views
from django.views import View
from django import forms
from django.http import JsonResponse

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'assigned_to', 'due_date']

class TasksView(LoginRequiredMixin, ListView):
    model = Task
    template_name = 'portal/tasks.html'
    context_object_name = 'tasks'

    def get_queryset(self):
        return Task.objects.filter(assigned_to=self.request.user).order_by('-created_at')

class CreateTaskView(LoginRequiredMixin, CreateView):
    model = Task
    form_class = TaskForm
    template_name = 'portal/create_task.html'
    success_url = reverse_lazy('tasks')

    def form_valid(self, form):
        if not form.instance.assigned_to:
            form.instance.assigned_to = self.request.user
        messages.success(self.request, 'Задача создана.')
        return super().form_valid(form)

class ToggleTaskView(LoginRequiredMixin, View):
    def post(self, request, pk):
        task = get_object_or_404(Task, pk=pk, assigned_to=request.user)
        task.completed = not task.completed
        task.save()
        return JsonResponse({'completed': task.completed})

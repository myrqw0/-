#!/usr/bin/env python
import os
import sys
import django

# Налаштування Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'group_portal.settings')
django.setup()

from django.contrib.auth.models import User
from portal.models import UserRole, UserProfile

def create_superuser():
    # Створюємо суперкористувача
    username = 'admin'
    email = 'admin@example.com'
    password = 'admin123'
    
    if User.objects.filter(username=username).exists():
        print(f"Користувач {username} вже існує")
        return
    
    user = User.objects.create_superuser(username, email, password)
    
    # Створюємо роль адміністратора
    UserRole.objects.create(user=user, role='admin')
    
    # Створюємо профіль
    UserProfile.objects.create(user=user)
    
    print(f"Створено суперкористувача: {username} з паролем: {password}")

if __name__ == '__main__':
    create_superuser()

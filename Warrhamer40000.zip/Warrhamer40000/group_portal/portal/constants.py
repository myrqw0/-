"""
Константы для приложения portal
"""

# Роли пользователей
class UserRoles:
    USER = 'user'
    MODERATOR = 'moderator'
    ADMIN = 'admin'
    
    CHOICES = [
        (USER, 'Пользователь'),
        (MODERATOR, 'Модератор'),
        (ADMIN, 'Администратор'),
    ]
    
    STAFF_ROLES = [MODERATOR, ADMIN]


# Типы вопросов в опросах
class QuestionTypes:
    TEXT = 'text'
    CHOICE = 'choice'
    MULTIPLE = 'multiple'
    
    CHOICES = [
        (TEXT, 'Текст'),
        (CHOICE, 'Выбор'),
        (MULTIPLE, 'Множественный выбор'),
    ]


# Типы материалов
class MaterialTypes:
    FILE = 'file'
    LINK = 'link'
    VIDEO = 'video'
    
    CHOICES = [
        (FILE, 'Файл'),
        (LINK, 'Ссылка'),
        (VIDEO, 'Видео'),
    ]


# Типы элементов галереи
class GalleryItemTypes:
    IMAGE = 'image'
    VIDEO = 'video'
    
    CHOICES = [
        (IMAGE, 'Изображение'),
        (VIDEO, 'Видео'),
    ]


# Диапазоны оценок
class GradeRanges:
    EXCELLENT_MIN = 9
    EXCELLENT_MAX = 12
    GOOD_MIN = 7
    GOOD_MAX = 8
    SATISFACTORY_MIN = 4
    SATISFACTORY_MAX = 6
    POOR_MIN = 1
    POOR_MAX = 3

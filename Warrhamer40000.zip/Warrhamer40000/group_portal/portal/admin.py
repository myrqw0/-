from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from .models import *

# Розширення UserAdmin для відображення додаткових полів
class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Профіль користувача'

class UserRoleInline(admin.StackedInline):
    model = UserRole
    can_delete = False
    verbose_name_plural = 'Роль користувача'

class CustomUserAdmin(UserAdmin):
    inlines = (UserProfileInline, UserRoleInline)
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'get_role')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'date_joined')

    def get_role(self, obj):
        try:
            return obj.userrole.get_role_display()
        except:
            return 'Не встановлено'
    get_role.short_description = 'Роль'

# Перереєстрація User
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)

# Адміністративні класи для моделей
@admin.register(UserRole)
class UserRoleAdmin(admin.ModelAdmin):
    list_display = ('user', 'role')
    list_filter = ('role',)
    search_fields = ('user__username', 'user__email')

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'first_name', 'last_name')
    search_fields = ('user__username', 'first_name', 'last_name')

@admin.register(ForumThread)
class ForumThreadAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'created_at', 'updated_at')
    list_filter = ('created_at', 'updated_at')
    search_fields = ('title', 'content', 'author__username')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(ForumPost)
class ForumPostAdmin(admin.ModelAdmin):
    list_display = ('thread', 'author', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('content', 'author__username', 'thread__title')
    readonly_fields = ('created_at',)

@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ('student', 'subject', 'grade', 'teacher', 'date')
    list_filter = ('subject', 'grade', 'date', 'teacher')
    search_fields = ('student__username', 'teacher__username', 'subject')
    date_hierarchy = 'date'

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'location', 'created_by', 'created_at')
    list_filter = ('date', 'created_at', 'created_by')
    search_fields = ('title', 'description', 'location')
    readonly_fields = ('created_at',)

@admin.register(Survey)
class SurveyAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_by', 'created_at', 'is_active')
    list_filter = ('is_active', 'created_at', 'created_by')
    search_fields = ('title', 'description')
    readonly_fields = ('created_at',)

@admin.register(SurveyQuestion)
class SurveyQuestionAdmin(admin.ModelAdmin):
    list_display = ('survey', 'question_text', 'question_type', 'required', 'order')
    list_filter = ('question_type', 'required', 'survey')
    search_fields = ('question_text', 'survey__title')
    ordering = ('survey', 'order')

@admin.register(SurveyChoice)
class SurveyChoiceAdmin(admin.ModelAdmin):
    list_display = ('question', 'choice_text')
    search_fields = ('choice_text', 'question__question_text')

@admin.register(SurveyResponse)
class SurveyResponseAdmin(admin.ModelAdmin):
    list_display = ('survey', 'user', 'completed_at')
    list_filter = ('completed_at', 'survey')
    search_fields = ('user__username', 'survey__title')
    readonly_fields = ('completed_at',)

@admin.register(SurveyAnswer)
class SurveyAnswerAdmin(admin.ModelAdmin):
    list_display = ('response', 'question', 'answer_text')
    search_fields = ('answer_text', 'question__question_text', 'response__user__username')

@admin.register(Voting)
class VotingAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_by', 'created_at', 'end_date', 'is_active')
    list_filter = ('is_active', 'created_at', 'end_date', 'created_by')
    search_fields = ('title', 'description')
    readonly_fields = ('created_at',)

@admin.register(VotingOption)
class VotingOptionAdmin(admin.ModelAdmin):
    list_display = ('voting', 'option_text')
    search_fields = ('option_text', 'voting__title')

@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ('voting', 'user', 'option', 'voted_at')
    list_filter = ('voted_at', 'voting')
    search_fields = ('user__username', 'voting__title', 'option__option_text')
    readonly_fields = ('voted_at',)

@admin.register(Announcement)
class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_by', 'created_at', 'is_active')
    list_filter = ('is_active', 'created_at', 'created_by')
    search_fields = ('title', 'content')
    readonly_fields = ('created_at',)

@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ('title', 'material_type', 'uploaded_by', 'uploaded_at')
    list_filter = ('material_type', 'uploaded_at', 'uploaded_by')
    search_fields = ('title', 'description')
    readonly_fields = ('uploaded_at',)

@admin.register(Portfolio)
class PortfolioAdmin(admin.ModelAdmin):
    list_display = ('user', 'title', 'created_at')
    list_filter = ('created_at', 'user')
    search_fields = ('title', 'description', 'user__username')
    readonly_fields = ('created_at',)

@admin.register(GalleryItem)
class GalleryItemAdmin(admin.ModelAdmin):
    list_display = ('title', 'item_type', 'uploaded_by', 'uploaded_at', 'approved')
    list_filter = ('item_type', 'approved', 'uploaded_at', 'uploaded_by')
    search_fields = ('title', 'description')
    readonly_fields = ('uploaded_at',)
    list_editable = ('approved',)

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'assigned_to', 'completed', 'due_date', 'created_at')
    list_filter = ('completed', 'due_date', 'created_at', 'assigned_to')
    search_fields = ('title', 'description')
    readonly_fields = ('created_at',)
    list_editable = ('completed',)

# Налаштування адміністративного інтерфейсу
admin.site.site_header = "Адміністрація Порталу групи"
admin.site.site_title = "Портал групи"
admin.site.index_title = "Панель управління"


"""
Миксины для views
"""
from django.contrib.auth.mixins import UserPassesTestMixin
from django.core.exceptions import PermissionDenied
from .constants import UserRoles


class StaffRequiredMixin(UserPassesTestMixin):
    """
    Миксин для проверки, что пользователь является модератором или администратором
    """
    def test_func(self):
        if not self.request.user.is_authenticated:
            return False
        try:
            return self.request.user.userrole.role in UserRoles.STAFF_ROLES
        except AttributeError:
            return False


class ModeratorRequiredMixin(UserPassesTestMixin):
    """
    Миксин для проверки, что пользователь является модератором
    """
    def test_func(self):
        if not self.request.user.is_authenticated:
            return False
        try:
            return self.request.user.userrole.role == UserRoles.MODERATOR
        except AttributeError:
            return False


class AdminRequiredMixin(UserPassesTestMixin):
    """
    Миксин для проверки, что пользователь является администратором
    """
    def test_func(self):
        if not self.request.user.is_authenticated:
            return False
        try:
            return self.request.user.userrole.role == UserRoles.ADMIN
        except AttributeError:
            return False


class SetAuthorMixin:
    """
    Миксин для автоматической установки автора при создании объекта
    """
    author_field = 'author'
    
    def form_valid(self, form):
        setattr(form.instance, self.author_field, self.request.user)
        return super().form_valid(form)


class SetCreatedByMixin:
    """
    Миксин для автоматической установки created_by при создании объекта
    """
    created_by_field = 'created_by'
    
    def form_valid(self, form):
        setattr(form.instance, self.created_by_field, self.request.user)
        return super().form_valid(form)


class SetUploadedByMixin:
    """
    Миксин для автоматической установки uploaded_by при создании объекта
    """
    uploaded_by_field = 'uploaded_by'
    
    def form_valid(self, form):
        setattr(form.instance, self.uploaded_by_field, self.request.user)
        return super().form_valid(form)


class SetUserMixin:
    """
    Миксин для автоматической установки user при создании объекта
    """
    user_field = 'user'
    
    def form_valid(self, form):
        setattr(form.instance, self.user_field, self.request.user)
        return super().form_valid(form)


class SetTeacherMixin:
    """
    Миксин для автоматической установки teacher при создании оценки
    """
    teacher_field = 'teacher'
    
    def form_valid(self, form):
        setattr(form.instance, self.teacher_field, self.request.user)
        return super().form_valid(form)

from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from datetime import datetime, timedelta
from .models import *

class PortalTestCase(TestCase):
    def setUp(self):
        """Налаштування тестових даних"""
        # Створюємо тестових користувачів
        self.user1 = User.objects.create_user(
            username='testuser1',
            email='test1@example.com',
            password='testpass123'
        )
        self.user2 = User.objects.create_user(
            username='testuser2',
            email='test2@example.com',
            password='testpass123'
        )
        
        # Створюємо ролі
        self.user_role1 = UserRole.objects.create(user=self.user1, role='user')
        self.user_role2 = UserRole.objects.create(user=self.user2, role='admin')
        
        # Створюємо профілі
        self.profile1 = UserProfile.objects.create(user=self.user1)
        self.profile2 = UserProfile.objects.create(user=self.user2)
        
        # Створюємо тестові дані
        self.forum_thread = ForumThread.objects.create(
            title='Тестова тема',
            content='Тестовий контент',
            author=self.user1
        )
        
        self.event = Event.objects.create(
            title='Тестова подія',
            description='Тестовий опис',
            date=timezone.now() + timedelta(days=1),
            location='Тестове місце',
            created_by=self.user2
        )
        
        self.survey = Survey.objects.create(
            title='Тестовий опитування',
            description='Тестовий опис',
            created_by=self.user2
        )
        
        self.voting = Voting.objects.create(
            title='Тестове голосування',
            description='Тестовий опис',
            created_by=self.user2,
            end_date=timezone.now() + timedelta(days=7)
        )
        
        self.announcement = Announcement.objects.create(
            title='Тестове оголошення',
            content='Тестовий контент',
            created_by=self.user2
        )
        
        self.client = Client()

class AuthenticationTests(PortalTestCase):
    """Тести системи автентифікації"""
    
    def test_user_registration(self):
        """Тест реєстрації користувача"""
        response = self.client.post(reverse('register'), {
            'username': 'newuser',
            'password1': 'newpass123',
            'password2': 'newpass123'
        })
        self.assertEqual(response.status_code, 302)  # Редирект після успішної реєстрації
        self.assertTrue(User.objects.filter(username='newuser').exists())
    
    def test_user_login(self):
        """Тест входу користувача"""
        response = self.client.post(reverse('login'), {
            'username': 'testuser1',
            'password': 'testpass123'
        })
        self.assertEqual(response.status_code, 302)  # Редирект після успішного входу
    
    def test_user_logout(self):
        """Тест виходу користувача"""
        self.client.login(username='testuser1', password='testpass123')
        response = self.client.get(reverse('logout'))
        self.assertEqual(response.status_code, 302)  # Редирект після виходу

class ForumTests(PortalTestCase):
    """Тести форуму"""
    
    def test_forum_list_view(self):
        """Тест відображення списку тем форуму"""
        response = self.client.get(reverse('forum'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Тестова тема')
    
    def test_create_forum_thread(self):
        """Тест створення нової теми форуму"""
        self.client.login(username='testuser1', password='testpass123')
        response = self.client.post(reverse('create_thread'), {
            'title': 'Нова тема',
            'content': 'Новий контент'
        })
        self.assertEqual(response.status_code, 302)  # Редирект після створення
        self.assertTrue(ForumThread.objects.filter(title='Нова тема').exists())
    
    def test_forum_thread_detail(self):
        """Тест відображення деталей теми форуму"""
        response = self.client.get(reverse('forum_thread', kwargs={'pk': self.forum_thread.pk}))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Тестова тема')

class EventTests(PortalTestCase):
    """Тести подій"""
    
    def test_events_list_view(self):
        """Тест відображення списку подій"""
        response = self.client.get(reverse('events'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Тестова подія')
    
    def test_create_event(self):
        """Тест створення нової події"""
        self.client.login(username='testuser2', password='testpass123')
        response = self.client.post(reverse('create_event'), {
            'title': 'Нова подія',
            'description': 'Новий опис',
            'date': (timezone.now() + timedelta(days=2)).strftime('%Y-%m-%dT%H:%M'),
            'location': 'Нове місце'
        })
        self.assertEqual(response.status_code, 302)  # Редирект після створення
        self.assertTrue(Event.objects.filter(title='Нова подія').exists())

class SurveyTests(PortalTestCase):
    """Тести опитувань"""
    
    def test_surveys_list_view(self):
        """Тест відображення списку опитувань"""
        response = self.client.get(reverse('surveys'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Тестовий опитування')
    
    def test_create_survey(self):
        """Тест створення нового опитування"""
        self.client.login(username='testuser2', password='testpass123')
        response = self.client.post(reverse('create_survey'), {
            'title': 'Нове опитування',
            'description': 'Новий опис'
        })
        self.assertEqual(response.status_code, 302)  # Редирект після створення
        self.assertTrue(Survey.objects.filter(title='Нове опитування').exists())

class VotingTests(PortalTestCase):
    """Тести голосувань"""
    
    def test_votings_list_view(self):
        """Тест відображення списку голосувань"""
        response = self.client.get(reverse('votings'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Тестове голосування')
    
    def test_create_voting(self):
        """Тест створення нового голосування"""
        self.client.login(username='testuser2', password='testpass123')
        response = self.client.post(reverse('create_voting'), {
            'title': 'Нове голосування',
            'description': 'Новий опис',
            'end_date': (timezone.now() + timedelta(days=7)).strftime('%Y-%m-%dT%H:%M')
        })
        self.assertEqual(response.status_code, 302)  # Редирект після створення
        self.assertTrue(Voting.objects.filter(title='Нове голосування').exists())

class AnnouncementTests(PortalTestCase):
    """Тести оголошень"""
    
    def test_announcements_list_view(self):
        """Тест відображення списку оголошень"""
        response = self.client.get(reverse('announcements'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Тестове оголошення')
    
    def test_create_announcement(self):
        """Тест створення нового оголошення"""
        self.client.login(username='testuser2', password='testpass123')
        response = self.client.post(reverse('create_announcement'), {
            'title': 'Нове оголошення',
            'content': 'Новий контент'
        })
        self.assertEqual(response.status_code, 302)  # Редирект після створення
        self.assertTrue(Announcement.objects.filter(title='Нове оголошення').exists())

class HomePageTests(PortalTestCase):
    """Тести головної сторінки"""
    
    def test_home_page(self):
        """Тест відображення головної сторінки"""
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Добро пожаловать в Портал группы!')
    
    def test_home_page_with_authenticated_user(self):
        """Тест головної сторінки для авторизованого користувача"""
        self.client.login(username='testuser1', password='testpass123')
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Добро пожаловать в Портал группы!')

class ModelTests(TestCase):
    """Тести моделей"""
    
    def test_user_role_creation(self):
        """Тест створення ролі користувача"""
        user = User.objects.create_user(username='test', password='test')
        role = UserRole.objects.create(user=user, role='admin')
        self.assertEqual(role.role, 'admin')
        self.assertEqual(str(role), f"{user.username} - Администратор")
    
    def test_user_profile_creation(self):
        """Тест створення профілю користувача"""
        user = User.objects.create_user(username='test', password='test')
        profile = UserProfile.objects.create(user=user, first_name='Test', last_name='User')
        self.assertEqual(profile.first_name, 'Test')
        self.assertEqual(str(profile), f"{user.username} профиль")
    
    def test_forum_thread_creation(self):
        """Тест створення теми форуму"""
        user = User.objects.create_user(username='test', password='test')
        thread = ForumThread.objects.create(
            title='Test Thread',
            content='Test Content',
            author=user
        )
        self.assertEqual(thread.title, 'Test Thread')
        self.assertEqual(str(thread), 'Test Thread')
    
    def test_grade_creation(self):
        """Тест створення оцінки"""
        student = User.objects.create_user(username='student', password='test')
        teacher = User.objects.create_user(username='teacher', password='test')
        grade = Grade.objects.create(
            student=student,
            subject='Math',
            grade=10,
            date=timezone.now().date(),
            teacher=teacher
        )
        self.assertEqual(grade.grade, 10)
        self.assertEqual(str(grade), f"{student.username} - Math: 10")

class PermissionTests(PortalTestCase):
    """Тести дозволів"""
    
    def test_admin_can_create_event(self):
        """Тест: адміністратор може створювати події"""
        self.client.login(username='testuser2', password='testpass123')
        response = self.client.get(reverse('create_event'))
        self.assertEqual(response.status_code, 200)
    
    def test_user_cannot_create_event(self):
        """Тест: звичайний користувач не може створювати події"""
        self.client.login(username='testuser1', password='testpass123')
        response = self.client.get(reverse('create_event'))
        self.assertEqual(response.status_code, 403)  # Forbidden
    
    def test_admin_can_create_survey(self):
        """Тест: адміністратор може створювати опитування"""
        self.client.login(username='testuser2', password='testpass123')
        response = self.client.get(reverse('create_survey'))
        self.assertEqual(response.status_code, 200)
    
    def test_user_cannot_create_survey(self):
        """Тест: звичайний користувач не може створювати опитування"""
        self.client.login(username='testuser1', password='testpass123')
        response = self.client.get(reverse('create_survey'))
        self.assertEqual(response.status_code, 403)  # Forbidden


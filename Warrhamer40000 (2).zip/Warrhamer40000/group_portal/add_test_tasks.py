import os
import django
import sys
from datetime import datetime, timedelta

# Настройка Django
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'group_portal.settings')
django.setup()

from django.contrib.auth.models import User
from portal.models import Task

def add_test_tasks():
    """Добавляет тестовые задания для всех пользователей"""
    
    users = User.objects.all()
    
    if not users.exists():
        print("❌ Нет пользователей в системе. Сначала создайте пользователей.")
        return
    
    # Список тестовых заданий
    test_tasks = [
        {
            'title': 'Подготовить презентацию по истории',
            'description': 'Создать презентацию на тему "Вторая мировая война" на 15-20 слайдов',
            'due_date': datetime.now() + timedelta(days=7),
            'completed': False
        },
        {
            'title': 'Решить задачи по математике',
            'description': 'Решить задачи №15-30 из учебника, страница 45',
            'due_date': datetime.now() + timedelta(days=3),
            'completed': False
        },
        {
            'title': 'Написать эссе по литературе',
            'description': 'Эссе на тему "Образ главного героя в романе" (минимум 500 слов)',
            'due_date': datetime.now() + timedelta(days=10),
            'completed': False
        },
        {
            'title': 'Подготовиться к контрольной по физике',
            'description': 'Повторить темы: механика, термодинамика, электричество',
            'due_date': datetime.now() + timedelta(days=5),
            'completed': False
        },
        {
            'title': 'Сделать лабораторную работу по химии',
            'description': 'Выполнить лабораторную работу №3 и оформить отчет',
            'due_date': datetime.now() + timedelta(days=14),
            'completed': False
        },
        {
            'title': 'Прочитать главы 5-8 по английскому',
            'description': 'Прочитать и перевести текст, выписать новые слова',
            'due_date': datetime.now() + timedelta(days=4),
            'completed': True
        },
        {
            'title': 'Подготовить доклад по биологии',
            'description': 'Доклад на тему "Эволюция живых организмов" на 10 минут',
            'due_date': datetime.now() + timedelta(days=12),
            'completed': False
        },
        {
            'title': 'Выполнить упражнения по грамматике',
            'description': 'Упражнения 1-10 на страницах 67-70',
            'due_date': datetime.now() + timedelta(days=2),
            'completed': True
        },
    ]
    
    created_count = 0
    
    for user in users:
        print(f"\n📝 Создание заданий для пользователя: {user.username}")
        
        # Создаем 3-5 случайных заданий для каждого пользователя
        import random
        selected_tasks = random.sample(test_tasks, min(5, len(test_tasks)))
        
        for task_data in selected_tasks:
            task, created = Task.objects.get_or_create(
                title=task_data['title'],
                assigned_to=user,
                defaults={
                    'description': task_data['description'],
                    'due_date': task_data['due_date'],
                    'completed': task_data['completed']
                }
            )
            
            if created:
                status = "✅ выполнено" if task.completed else "⏳ в процессе"
                print(f"  ✓ {task.title} ({status})")
                created_count += 1
            else:
                print(f"  ⚠ {task.title} (уже существует)")
    
    print(f"\n🎉 Всего создано заданий: {created_count}")
    print("✅ Тестовые задания успешно добавлены!")

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 Добавление тестовых заданий")
    print("=" * 60)
    add_test_tasks()


# Інструкція з розгортання Порталу групи

## Підготовка до розгортання

### 1. Перевірка готовності проекту

Перед розгортанням переконайтеся, що:
- ✅ Всі тести пройдені успішно
- ✅ Налаштовано змінні середовища
- ✅ База даних підготовлена
- ✅ Статичні файли зібрані

### 2. Налаштування змінних середовища

Створіть файл `.env` на сервері:

```env
# Django settings
SECRET_KEY=<генеруйте_новий_секретний_ключ>
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com

# Database (PostgreSQL)
DB_NAME=portal_db
DB_USER=portal_user
DB_PASSWORD=<secure_password>
DB_HOST=localhost
DB_PORT=5432

# Email
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=<app_password>

# Security
SECURE_SSL_REDIRECT=True
SESSION_COOKIE_SECURE=True
CSRF_COOKIE_SECURE=True
SECURE_HSTS_SECONDS=31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS=True
SECURE_HSTS_PRELOAD=True
```

### 3. Генерація SECRET_KEY

```python
from django.core.management.utils import get_random_secret_key
print(get_random_secret_key())
```

## Варіанти розгортання

### Варіант 1: Розгортання на Heroku

#### Крок 1: Підготовка проекту

1. Встановіть Heroku CLI
2. Створіть файл `Procfile`:
```
web: gunicorn group_portal.wsgi
```

3. Створіть файл `runtime.txt`:
```
python-3.11.0
```

4. Оновіть `requirements.txt`:
```bash
pip freeze > requirements.txt
```

Додайте до `requirements.txt`:
```
gunicorn==21.2.0
psycopg2-binary==2.9.9
dj-database-url==2.1.0
whitenoise==6.6.0
```

#### Крок 2: Налаштування whitenoise для статичних файлів

У `settings.py`:
```python
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',  # Додайте цей рядок
    ...
]

STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'
```

#### Крок 3: Налаштування бази даних

У `settings.py`:
```python
import dj_database_url

DATABASES = {
    'default': dj_database_url.config(
        default=config('DATABASE_URL', default='sqlite:///db.sqlite3')
    )
}
```

#### Крок 4: Розгортання

```bash
heroku login
heroku create your-app-name
git push heroku main
heroku run python manage.py migrate
heroku run python create_admin.py
heroku open
```

### Варіант 2: Розгортання на DigitalOcean/VPS

#### Крок 1: Підготовка сервера

```bash
# Оновлення системи
sudo apt update
sudo apt upgrade -y

# Встановлення необхідних пакетів
sudo apt install python3-pip python3-dev libpq-dev postgresql postgresql-contrib nginx -y
```

#### Крок 2: Налаштування PostgreSQL

```bash
sudo -u postgres psql

# У psql:
CREATE DATABASE portal_db;
CREATE USER portal_user WITH PASSWORD 'your_password';
ALTER ROLE portal_user SET client_encoding TO 'utf8';
ALTER ROLE portal_user SET default_transaction_isolation TO 'read committed';
ALTER ROLE portal_user SET timezone TO 'UTC';
GRANT ALL PRIVILEGES ON DATABASE portal_db TO portal_user;
\q
```

#### Крок 3: Завантаження проекту

```bash
cd /var/www
sudo git clone <your-repo-url> group_portal
cd group_portal
sudo python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn
```

#### Крок 4: Налаштування проекту

```bash
# Створіть .env файл
nano .env

# Запустіть міграції
python manage.py migrate
python create_admin.py
python manage.py collectstatic
```

#### Крок 5: Налаштування Gunicorn

Створіть файл `/etc/systemd/system/gunicorn.service`:

```ini
[Unit]
Description=gunicorn daemon for Django project
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/group_portal
Environment="PATH=/var/www/group_portal/venv/bin"
ExecStart=/var/www/group_portal/venv/bin/gunicorn \
    --workers 3 \
    --bind unix:/var/www/group_portal/gunicorn.sock \
    group_portal.wsgi:application

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl start gunicorn
sudo systemctl enable gunicorn
```

#### Крок 6: Налаштування Nginx

Створіть файл `/etc/nginx/sites-available/group_portal`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location = /favicon.ico { access_log off; log_not_found off; }
    
    location /static/ {
        root /var/www/group_portal;
    }
    
    location /media/ {
        root /var/www/group_portal;
    }

    location / {
        include proxy_params;
        proxy_pass http://unix:/var/www/group_portal/gunicorn.sock;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/group_portal /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx
```

#### Крок 7: Налаштування SSL (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

### Варіант 3: Розгортання на PythonAnywhere

#### Крок 1: Завантаження коду

```bash
git clone <your-repo-url> group_portal
cd group_portal
mkvirtualenv --python=/usr/bin/python3.10 group_portal_env
pip install -r requirements.txt
```

#### Крок 2: Налаштування веб-додатку

1. Перейдіть до вкладки "Web"
2. Додайте новий веб-додаток
3. Виберіть Manual configuration (Python 3.10)
4. Налаштуйте WSGI:

```python
import os
import sys

path = '/home/yourusername/group_portal'
if path not in sys.path:
    sys.path.append(path)

os.environ['DJANGO_SETTINGS_MODULE'] = 'group_portal.settings'

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
```

5. Налаштуйте статичні файли:
   - URL: /static/
   - Directory: /home/yourusername/group_portal/staticfiles/

6. Налаштуйте media файли:
   - URL: /media/
   - Directory: /home/yourusername/group_portal/media/

#### Крок 3: Запуск міграцій

```bash
python manage.py migrate
python create_admin.py
python manage.py collectstatic
```

## Після розгортання

### Перевірка

1. Перевірте головну сторінку
2. Спробуйте увійти як адміністратор
3. Перевірте всі основні функції
4. Перевірте завантаження статичних файлів
5. Перевірте завантаження медіа файлів

### Моніторинг

```bash
# Перегляд логів Gunicorn
sudo journalctl -u gunicorn -f

# Перегляд логів Nginx
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log

# Перегляд логів Django
tail -f /var/www/group_portal/logs/django.log
```

### Регулярне обслуговування

1. **Резервне копіювання бази даних**:
```bash
pg_dump portal_db > backup_$(date +%Y%m%d).sql
```

2. **Оновлення проекту**:
```bash
cd /var/www/group_portal
git pull origin main
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic --noinput
sudo systemctl restart gunicorn
```

3. **Очищення старих сесій**:
```bash
python manage.py clearsessions
```

## Troubleshooting (Вирішення проблем)

### Проблема: 502 Bad Gateway
**Рішення**: Перевірте, чи запущений Gunicorn
```bash
sudo systemctl status gunicorn
sudo systemctl restart gunicorn
```

### Проблема: Статичні файли не завантажуються
**Рішення**: Зберіть статичні файли знову
```bash
python manage.py collectstatic --noinput
sudo systemctl restart nginx
```

### Проблема: Помилки бази даних
**Рішення**: Перевірте підключення до бази даних
```bash
sudo -u postgres psql
\l
\c portal_db
\dt
```

### Проблема: Permission denied
**Рішення**: Налаштуйте права доступу
```bash
sudo chown -R www-data:www-data /var/www/group_portal
sudo chmod -R 755 /var/www/group_portal
```

## Безпека

### Checklist безпеки

- [ ] DEBUG = False у продакшні
- [ ] Сильний SECRET_KEY
- [ ] HTTPS налаштовано
- [ ] ALLOWED_HOSTS правильно налаштовано
- [ ] Файрвол налаштовано
- [ ] Регулярні резервні копії
- [ ] Оновлення залежностей
- [ ] Логування налаштовано
- [ ] CSRF та XSS захист увімкнено
- [ ] SQL injection захист (Django ORM)

---

**Важливо**: Завжди тестуйте розгортання спочатку на тестовому сервері!



#!/usr/bin/env python3
"""
Code Guardian - AI-powered code error detection and auto-fix system
Мини-программа для автоматического обнаружения и исправления ошибок в коде
"""

import os
import sys
import time
import json
import ast
import re
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict
import logging
from concurrent.futures import ThreadPoolExecutor
import hashlib

try:
    import matplotlib.pyplot as plt
    import seaborn as sns
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    print("Warning: matplotlib not available. Charts will be disabled.")

from collections import defaultdict

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('code_guardian.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('CodeGuardian')

@dataclass
class CodeIssue:
    """Структура для хранения информации об ошибке в коде"""
    file_path: str
    line_number: int
    column: int
    error_type: str
    severity: str  # 'error', 'warning', 'info'
    message: str
    code_snippet: str
    suggested_fix: Optional[str] = None
    confidence: float = 0.0
    timestamp: float = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

@dataclass
class CodeMetrics:
    """Метрики качества кода"""
    file_path: str
    lines_of_code: int
    complexity: int
    issues_count: int
    maintainability_index: float
    timestamp: float = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

@dataclass
class GitCommit:
    """Информация о Git коммите"""
    hash: str
    author: str
    date: str
    message: str
    files_changed: List[str]
    insertions: int
    deletions: int

class CodeAnalyzer:
    """Анализатор кода для обнаружения ошибок"""

    def __init__(self):
        self.error_patterns = {
            'python': {
                'syntax_errors': [
                    (r'print\s*\(', 'Missing parentheses in print statement'),
                    (r'except\s*:', 'Bare except clause'),
                    (r'^\s*def\s+\w+\s*\([^)]*$', 'Unclosed function definition'),
                ],
                'style_issues': [
                    (r'\bif\s*\(\s*', 'Unnecessary parentheses in if statement'),
                    (r'\bfor\s+\w+\s+in\s+range\s*\(\s*len\s*\(\s*(\w+)\s*\)\s*\)'\
     'Use enumerate instead of range(len(...
                ],
                'security_issues': [
                    (r'eval\s*\(', 'Use of eval() is dangerous'),
                    (r'exec\s*\(', 'Use of exec() is dangerous'),
                    (r'input\s*\(\s*["\']', 'Raw input without validation'),
                ]
            },
            'javascript': {
                'syntax_errors': [
                    (r'console\.log\s*\(', 'Use console.log with proper formatting'),
                    (r'var\s+', 'Use let/const instead of var'),
                    (r'==\s*', 'Use === instead of == for comparison'),
                ],
                'style_issues': [
                    (r'function\s+\w+\s*\([^)]*\)\s*\{[^}]*[^;]\s*\}', 'Missing semicolon'),
                    (r'\bif\s*\([^)]+\)\s*\{[^}]*[^;]\s*\}', 'Missing semicolon in if statement'),
                ],
                'security_issues': [
                    (r'innerHTML\s*=', 'Use textContent or createElement for security'),
                    (r'eval\s*\(', 'Use of eval() is dangerous'),
                    (r'document\.write\s*\(', 'Avoid document.write'),
                ]
            },
            'html': {
                'syntax_errors': [
                    (r'<[^>]*\s+[^>]*>', 'Check for unclosed HTML tags'),
                    (r'<img[^>]*>', 'Missing alt attribute in img tag'),
                ],
                'accessibility_issues': [
                    (r'<meta[^>]*name\s*=\s*["\']description["\'][^>]*content\s*=\s*["\'][^"\']*["\']'\
     'Missing meta de...
                    (r'<meta[^>]*name\s*=\s*["\']description["\'][^>]*content\s*=\s*["\'][^"\']*["\']', 'Missing meta description'),
                ]
            },
            'css': {
                'syntax_errors': [
                    (r'[^}]*\{[^}]*[^}]*\}', 'Check for unclosed CSS rules'),
                ],
                'style_issues': [
                    (r'!important', 'Avoid using !important'),
                    (r'#\w+\s*\{[^}]*width\s*:\s*\d+px', 'Consider using relative units'),
                ],
                'performance_issues': [
                    (r'\*\s*\{', 'Universal selector can impact performance'),
                    (r'@import', 'Avoid @import, use <link> instead'),
                ]
            }
        }

    def analyze_file(self, file_path: str) -> List[CodeIssue]:
        """Анализ одного файла"""
        issues = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')

            # Определение языка по расширению файла
            file_ext = file_path.split('.')[-1].lower()

            if file_ext == 'py':
                issues.extend(self._analyze_python_file(file_path, content, lines))
            elif file_ext in ['js', 'mjs', 'ts']:
                issues.extend(self._analyze_javascript_file(file_path, content, lines))
            elif file_ext in ['html', 'htm']:
                issues.extend(self._analyze_html_file(file_path, content, lines))
            elif file_ext == 'css':
                issues.extend(self._analyze_css_file(file_path, content, lines))

            # Общий анализ
            issues.extend(self._analyze_common_issues(file_path, content, lines))

        except Exception as e:
            logger.error(f"Error analyzing {file_path}: {e}")
            issues.append(CodeIssue(
                file_path=file_path,
                line_number=0,
                column=0,
                error_type='analysis_error',
                severity='error',
                message=f"Failed to analyze file: {str(e)}",
                code_snippet="",
                confidence=1.0
            ))

        return issues

    def _analyze_python_file(self, file_path: str, content: str, lines: List[str]) -> List[CodeIssue]:
        """Анализ Python файла"""
        issues = []

        try:
            # Попытка парсинга AST
            ast.parse(content)
        except SyntaxError as e:
            issues.append(CodeIssue(
                file_path=file_path,
                line_number=e.lineno or 0,
                column=e.offset or 0,
                error_type='syntax_error',
                severity='error',
                message=f"Syntax error: {e.msg}",
                code_snippet=lines[e.lineno - 1] if e.lineno and e.lineno <= len(lines) else "",
                suggested_fix=self._suggest_syntax_fix(e),
                confidence=1.0
            ))

        # Анализ паттернов
        for line_num, line in enumerate(lines, 1):
            for category, patterns in self.error_patterns['python'].items():
                for pattern, message in patterns:
                    if re.search(pattern, line):
                        severity = 'error' if category == 'syntax_errors' else 'warning' if category == 'style_issues' else 'info'
                        issues.append(CodeIssue(
                            file_path=file_path,
                            line_number=line_num,
                            column=0,
                            error_type=category[:-1],  # Remove 's' from plural
                            severity=severity,
                            message=message,
                            code_snippet=line.strip(),
                            suggested_fix=self._suggest_pattern_fix(pattern, line),
                            confidence=0.8
                        ))

        return issues

    def _analyze_javascript_file(self, file_path: str, content: str, lines: List[str]) -> List[CodeIssue]:
        """Анализ JavaScript файла"""
        issues = []

        # Анализ паттернов JavaScript
        for line_num, line in enumerate(lines, 1):
            for category, patterns in self.error_patterns['javascript'].items():
                for pattern, message in patterns:
                    if re.search(pattern, line):
                        severity = 'error' if category == 'syntax_errors' else 'warning' if category == 'style_issues' else 'info'
                        issues.append(CodeIssue(
                            file_path=file_path,
                            line_number=line_num,
                            column=0,
                            error_type=category[:-1],  # Remove 's' from plural
                            severity=severity,
                            message=message,
                            code_snippet=line.strip(),
                            suggested_fix=self._suggest_js_fix(pattern, line),
                            confidence=0.8
                        ))

        return issues

    def _analyze_html_file(self, file_path: str, content: str, lines: List[str]) -> List[CodeIssue]:
        """Анализ HTML файла"""
        issues = []

        # Анализ паттернов HTML
        for line_num, line in enumerate(lines, 1):
            for category, patterns in self.error_patterns['html'].items():
                for pattern, message in patterns:
                    if re.search(pattern, line):
                        severity = 'error' if category == 'syntax_errors' else 'warning' if category == 'accessibility_issues' else 'info'
                        issues.append(CodeIssue(
                            file_path=file_path,
                            line_number=line_num,
                            column=0,
                            error_type=category[:-1],  # Remove 's' from plural
                            severity=severity,
                            message=message,
                            code_snippet=line.strip(),
                            suggested_fix=self._suggest_html_fix(pattern, line),
                            confidence=0.7
                        ))

        return issues

    def _analyze_css_file(self, file_path: str, content: str, lines: List[str]) -> List[CodeIssue]:
        """Анализ CSS файла"""
        issues = []

        # Анализ паттернов CSS
        for line_num, line in enumerate(lines, 1):
            for category, patterns in self.error_patterns['css'].items():
                for pattern, message in patterns:
                    if re.search(pattern, line):
                        severity = 'error' if category == 'syntax_errors' else 'warning' if category == 'style_issues' else 'info'
                        issues.append(CodeIssue(
                            file_path=file_path,
                            line_number=line_num,
                            column=0,
                            error_type=category[:-1],  # Remove 's' from plural
                            severity=severity,
                            message=message,
                            code_snippet=line.strip(),
                            suggested_fix=self._suggest_css_fix(pattern, line),
                            confidence=0.6
                        ))

        return issues

    def _suggest_js_fix(self, pattern: str, line: str) -> Optional[str]:
        """Предложение исправления для JavaScript"""
        if 'var' in pattern:
            return 'Use let or const instead of var'
        elif '==' in pattern and '===' not in line:
            return 'Use === for strict equality comparison'
        elif 'innerHTML' in pattern:
            return 'Use textContent or createElement for better security'
        return None

    def _suggest_html_fix(self, pattern: str, line: str) -> Optional[str]:
        """Предложение исправления для HTML"""
        if 'img' in pattern and 'alt' not in line:
            return 'Add alt attribute to img tag for accessibility'
        elif '<title></title>' in line:
            return 'Add meaningful title content'
        return None

    def _suggest_css_fix(self, pattern: str, line: str) -> Optional[str]:
        """Предложение исправления для CSS"""
        if '!important' in pattern:
            return 'Avoid !important, use better specificity'
        elif '@import' in pattern:
            return 'Use <link> tag instead of @import for better performance'
        return None

    def _analyze_common_issues(self, file_path: str, content: str, lines: List[str]) -> List[CodeIssue]:
        """Общий анализ на распространенные проблемы"""
        issues = []

        # Проверка на TODO комментарии
        for line_num, line in enumerate(lines, 1):
            if 'TODO' in line.upper() or 'FIXME' in line.upper():
                issues.append(CodeIssue(
                    file_path=file_path,
                    line_number=line_num,
                    column=0,
                    error_type='todo_comment',
                    severity='info',
                    message='TODO or FIXME comment found',
                    code_snippet=line.strip(),
                    confidence=1.0
                ))

        # Проверка на длинные строки
        for line_num, line in enumerate(lines, 1):
            if len(line) > 120:
                issues.append(CodeIssue(
                    file_path=file_path,
                    line_number=line_num,
                    column=120,
                    error_type='long_line',
                    severity='warning',
                    message='Line too long (>120 characters)',
                    code_snippet=line[:120] + '...',
                    suggested_fix='Break line into multiple lines',
                    confidence=0.9
                ))

        return issues

    def _suggest_syntax_fix(self, error: SyntaxError) -> Optional[str]:
        """Предложение исправления синтаксической ошибки"""
        if 'unexpected EOF' in error.msg:
            return 'Check for missing closing brackets, parentheses, or quotes'
        elif 'invalid syntax' in error.msg:
            return 'Check for typos in keywords or operators'
        return None

    def _suggest_pattern_fix(self, pattern: str, line: str) -> Optional[str]:
        """Предложение исправления для паттерна"""
        if 'print' in pattern and '(' not in line:
            return 'Add parentheses: print(...)'
        elif 'except' in pattern and ':' in line:
            return 'Specify exception type: except Exception:'
        elif 'range(len(' in pattern:
            return 'Use enumerate() instead of range(len())'
        return None

class AutoFixer:
    """Автоматический исправитель ошибок"""

    def __init__(self):
        self.fix_rules = {
            'print_statement': self._fix_print_statement,
            'missing_parentheses': self._fix_missing_parentheses,
            'long_line': self._fix_long_line,
        }

    def can_fix(self, issue: CodeIssue) -> bool:
        """Проверка возможности автоматического исправления"""
        return issue.error_type in self.fix_rules and issue.confidence > 0.7

    def apply_fix(self, issue: CodeIssue) -> Optional[str]:
        """Применение исправления"""
        if issue.error_type in self.fix_rules:
            return self.fix_rules[issue.error_type](issue)
        return None

    def _fix_print_statement(self, issue: CodeIssue) -> Optional[str]:
        """Исправление print без скобок"""
        if 'print' in issue.code_snippet and '(' not in issue.code_snippet:
            # Простая замена
            fixed = re.sub(r'print\s+(.+)', r'print(\1)', issue.code_snippet)
            return fixed
        return None

    def _fix_missing_parentheses(self, issue: CodeIssue) -> Optional[str]:
        """Исправление отсутствующих скобок"""
        # Обобщенная логика для добавления скобок
        return f"({issue.code_snippet})"

    def _fix_long_line(self, issue: CodeIssue) -> Optional[str]:
        """Исправление длинной строки"""
        # Простое разбиение по запятым или операторам
        if ',' in issue.code_snippet:
            parts = issue.code_snippet.split(',')
            if len(parts) > 1:
                return '\\\n    '.join(parts)
        return None

class GitIntegration:
    """Интеграция с Git для отслеживания изменений"""

    def __init__(self, repo_path: Path):
        self.repo_path = repo_path

    def is_git_repo(self) -> bool:
        """Проверка, является ли директория Git репозиторием"""
        return (self.repo_path / '.git').exists()

    def get_recent_commits(self, limit: int = 10) -> List[GitCommit]:
        """Получение последних коммитов"""
        if not self.is_git_repo():
            return []

        try:
            # Получение информации о коммитах
            result = subprocess.run(
                ['git', 'log', f'--oneline', '-n', str(limit), '--pretty=format:%H|%an|%ad|%s', '--date=short'],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                encoding='utf-8'
            )

            commits = []
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.split('|', 3)
                    if len(parts) >= 4:
                        commit_hash, author, date, message = parts

                        # Получение списка измененных файлов
                        files_result = subprocess.run(
                            ['git', 'show', '--name-only', '--pretty=format:', commit_hash],
                            cwd=self.repo_path,
                            capture_output=True,
                            text=True,
                            encoding='utf-8'
                        )

                        files_changed = [f for f in files_result.stdout.strip().split('\n') if f]

                        commits.append(GitCommit(
                            hash=commit_hash[:8],  # Короткий хэш
                            author=author,
                            date=date,
                            message=message,
                            files_changed=files_changed,
                            insertions=0,  # Упрощенная версия
                            deletions=0
                        ))

            return commits

        except Exception as e:
            logger.error(f"Error getting Git commits: {e}")
            return []

    def get_commit_quality_trend(self, commits: List[GitCommit]) -> Dict[str, Any]:
        """Анализ тренда качества коммитов"""
        if not commits:
            return {'trend': 'no_data', 'quality_score': 0}

        # Простой анализ на основе количества файлов в коммитах
        avg_files = sum(len(commit.files_changed) for commit in commits) / len(commits)
        quality_score = max(0, 100 - (avg_files * 10))

        if quality_score > 70:
            trend = 'good'
        elif quality_score > 40:
            trend = 'average'
        else:
            trend = 'poor'

        return {'trend': trend, 'quality_score': quality_score}

class CodeGuardian:
    """Основной класс программы Code Guardian"""

    def __init__(self, watch_directory: str = '.'):
        self.watch_directory = Path(watch_directory)
        self.analyzer = CodeAnalyzer()
        self.fixer = AutoFixer()
        self.git_integration = GitIntegration(self.watch_directory)
        self.issues: Dict[str, List[CodeIssue]] = {}
        self.metrics: Dict[str, CodeMetrics] = {}
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.is_running = False

        # Создание директории для отчетов
        self.reports_dir = self.watch_directory / 'code_guardian_reports'
        self.reports_dir.mkdir(exist_ok=True)

    def start_monitoring(self):
        """Запуск мониторинга"""
        logger.info(f"Starting Code Guardian monitoring in {self.watch_directory}")
        self.is_running = True

        # Первоначальный анализ
        self._analyze_all_files()

        # Основной цикл мониторинга
        while self.is_running:
            try:
                self._check_for_changes()
                time.sleep(2)  # Проверка каждые 2 секунды
            except KeyboardInterrupt:
                logger.info("Stopping Code Guardian...")
                break
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(5)

    def stop_monitoring(self):
        """Остановка мониторинга"""
        self.is_running = False
        self.executor.shutdown()

    def _analyze_all_files(self):
        """Анализ всех файлов в директории"""
        logger.info("Starting full code analysis...")

        # Поддержка различных типов файлов
        file_patterns = {
            'python': '*.py',
            'javascript': ['*.js', '*.mjs', '*.ts'],
            'html': ['*.html', '*.htm'],
            'css': '*.css'
        }

        all_files = []
        for lang, patterns in file_patterns.items():
            if isinstance(patterns, list):
                for pattern in patterns:
                    all_files.extend(list(self.watch_directory.rglob(pattern)))
            else:
                all_files.extend(list(self.watch_directory.rglob(patterns)))

        futures = []

        for file_path in all_files:
            if not self._should_ignore_file(file_path):
                future = self.executor.submit(self._analyze_single_file, file_path)
                futures.append(future)

        # Ожидание завершения анализа
        for future in futures:
            try:
                future.result(timeout=30)
            except Exception as e:
                logger.error(f"Error in file analysis: {e}")

        logger.info(f"Analysis complete. Found issues in {len(self.issues)} files")

    def _analyze_single_file(self, file_path: Path):
        """Анализ одного файла"""
        try:
            issues = self.analyzer.analyze_file(str(file_path))
            if issues:
                self.issues[str(file_path)] = issues
                self._process_issues(file_path, issues)

            # Расчет метрик
            metrics = self._calculate_metrics(file_path)
            self.metrics[str(file_path)] = metrics

        except Exception as e:
            logger.error(f"Error analyzing {file_path}: {e}")

    def _process_issues(self, file_path: Path, issues: List[CodeIssue]):
        """Обработка найденных проблем"""
        auto_fixed = 0

        for issue in issues:
            logger.warning(f"[{issue.severity.upper()}] {file_path}:{issue.line_number} - {issue.message}")

            # Попытка автоматического исправления
            if self.fixer.can_fix(issue):
                fix = self.fixer.apply_fix(issue)
                if fix and self._apply_fix_to_file(file_path, issue, fix):
                    auto_fixed += 1
                    logger.info(f"Auto-fixed: {file_path}:{issue.line_number}")

        if auto_fixed > 0:
            logger.info(f"Auto-fixed {auto_fixed} issues in {file_path}")

    def _apply_fix_to_file(self, file_path: Path, issue: CodeIssue, fix: str) -> bool:
        """Применение исправления к файлу"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            if issue.line_number <= len(lines):
                # Замена строки
                lines[issue.line_number - 1] = fix + '\n'

                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(lines)

                return True

        except Exception as e:
            logger.error(f"Failed to apply fix to {file_path}: {e}")

        return False

    def _calculate_metrics(self, file_path: Path) -> CodeMetrics:
        """Расчет метрик файла"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')

            # Простой расчет метрик
            loc = len([line for line in lines if line.strip()])
            complexity = len(re.findall(r'\b(if|for|while|def|class)\b', content))
            issues_count = len(self.issues.get(str(file_path), []))

            # Упрощенный индекс поддерживаемости
            mi = max(0, 100 - (complexity * 2) - (issues_count * 5))

            return CodeMetrics(
                file_path=str(file_path),
                lines_of_code=loc,
                complexity=complexity,
                issues_count=issues_count,
                maintainability_index=mi
            )

        except Exception as e:
            logger.error(f"Error calculating metrics for {file_path}: {e}")
            return CodeMetrics(str(file_path), 0, 0, 0, 0)

    def _check_for_changes(self):
        """Проверка изменений в файлах"""
        # Проверка различных типов файлов
        file_patterns = ['*.py', '*.js', '*.mjs', '*.ts', '*.html', '*.htm', '*.css']

        for pattern in file_patterns:
            for file_path in self.watch_directory.rglob(pattern):
                if not self._should_ignore_file(file_path):
                    try:
                        current_mtime = file_path.stat().st_mtime
                        # Здесь можно добавить логику сравнения с предыдущим состоянием
                        # Пока просто переанализируем файлы периодически
                    except Exception as e:
                        logger.error(f"Error checking {file_path}: {e}")

    def _should_ignore_file(self, file_path: Path) -> bool:
        """Проверка, следует ли игнорировать файл"""
        ignore_patterns = [
            '__pycache__',
            '.git',
            'node_modules',
            'venv',
            'env',
            '.env',
            'code_guardian_reports'
        ]

        for pattern in ignore_patterns:
            if pattern in str(file_path):
                return True

        return False

    def generate_report(self, include_charts: bool = True) -> str:
        """Генерация отчета с графиками"""
        report = {
            'timestamp': time.time(),
            'total_files': len(self.metrics),
            'total_issues': sum(len(issues) for issues in self.issues.values()),
            'issues_by_severity': {},
            'issues_by_type': {},
            'issues_by_language': {},
            'metrics': [asdict(m) for m in self.metrics.values()],
            'issues': {},
            'charts': {}
        }

        # Статистика по типам и severity
        for file_issues in self.issues.values():
            for issue in file_issues:
                report['issues_by_severity'][issue.severity] = report['issues_by_severity'].get(issue.severity, 0) + 1
                report['issues_by_type'][issue.error_type] = report['issues_by_type'].get(issue.error_type, 0) + 1

                # Определение языка по расширению файла
                file_ext = issue.file_path.split('.')[-1].lower()
                lang_map = {'py': 'Python', 'js': 'JavaScript', 'ts': 'TypeScript', 'html': 'HTML', 'css': 'CSS'}
                lang = lang_map.get(file_ext, 'Other')
                report['issues_by_language'][lang] = report['issues_by_language'].get(lang, 0) + 1

        # Детальные проблемы
        for file_path, file_issues in self.issues.items():
            report['issues'][file_path] = [asdict(issue) for issue in file_issues]

        # Информация о Git
        if self.git_integration.is_git_repo():
            recent_commits = self.git_integration.get_recent_commits(10)
            report['git_info'] = {
                'is_git_repo': True,
                'recent_commits': [asdict(commit) for commit in recent_commits],
                'commit_trend': self.git_integration.get_commit_quality_trend(recent_commits)
            }
        else:
            report['git_info'] = {'is_git_repo': False}

        # Генерация графиков
        if include_charts:
            report['charts'] = self._generate_charts(report)

        # Сохранение отчета
        report_file = self.reports_dir / f'report_{int(time.time())}.json'
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        logger.info(f"Report generated: {report_file}")
        return str(report_file)

    def _generate_charts(self, report: Dict) -> Dict[str, str]:
        """Генерация графиков для отчета"""
        charts = {}
        charts_dir = self.reports_dir / 'charts'
        charts_dir.mkdir(exist_ok=True)

        if not HAS_MATPLOTLIB:
            logger.warning("matplotlib not available, skipping chart generation")
            return charts

        try:
            # Настройка стиля графиков
            plt.style.use('default')
            sns.set_palette("husl")

            # График распределения проблем по severity
            if report['issues_by_severity']:
                plt.figure(figsize=(10, 6))
                severities = list(report['issues_by_severity'].keys())
                counts = list(report['issues_by_severity'].values())

                colors = {'error': '#dc3545', 'warning': '#ffc107', 'info': '#17a2b8'}
                bar_colors = [colors.get(s, '#6c757d') for s in severities]

                plt.bar(severities, counts, color=bar_colors, alpha=0.8)
                plt.title('Распределение проблем по уровню серьезности', fontsize=14, fontweight='bold')
                plt.xlabel('Уровень серьезности')
                plt.ylabel('Количество проблем')
                plt.grid(axis='y', alpha=0.3)

                for i, v in enumerate(counts):
                    plt.text(i, v + 0.1, str(v), ha='center', fontweight='bold')

                chart_path = charts_dir / 'severity_distribution.png'
                plt.savefig(chart_path, dpi=150, bbox_inches='tight')
                plt.close()
                charts['severity_distribution'] = str(chart_path)

            # График распределения проблем по языкам
            if report['issues_by_language']:
                plt.figure(figsize=(10, 6))
                languages = list(report['issues_by_language'].keys())
                counts = list(report['issues_by_language'].values())

                plt.pie(counts, labels=languages, autopct='%1.1f%%', startangle=90)
                plt.title('Распределение проблем по языкам программирования', fontsize=14, fontweight='bold')
                plt.axis('equal')

                chart_path = charts_dir / 'language_distribution.png'
                plt.savefig(chart_path, dpi=150, bbox_inches='tight')
                plt.close()
                charts['language_distribution'] = str(chart_path)

            # График метрик поддерживаемости
            if self.metrics:
                maintainability_scores = [m.maintainability_index for m in self.metrics.values()]
                file_names = [Path(m.file_path).name for m in self.metrics.values()]

                plt.figure(figsize=(12, 6))
                bars = plt.barh(file_names, maintainability_scores, color='#28a745', alpha=0.7)
                plt.title('Индекс поддерживаемости кода по файлам', fontsize=14, fontweight='bold')
                plt.xlabel('Индекс поддерживаемости (0-100)')
                plt.ylabel('Файлы')
                plt.grid(axis='x', alpha=0.3)
                plt.xlim(0, 100)

                for bar, score in zip(bars, maintainability_scores):
                    plt.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2,
                           f'{score:.1f}', ha='left', va='center', fontweight='bold')

                chart_path = charts_dir / 'maintainability_index.png'
                plt.savefig(chart_path, dpi=150, bbox_inches='tight')
                plt.close()
                charts['maintainability_index'] = str(chart_path)

        except Exception as e:
            logger.error(f"Error generating charts: {e}")

        return charts

def main():
    """Главная функция"""
    import argparse

    parser = argparse.ArgumentParser(description='Code Guardian - AI-powered code error detection and auto-fix system')
    parser.add_argument('--directory', '-d', default='.', help='Directory to monitor')
    parser.add_argument('--report-only', action='store_true', help='Generate report only, do not monitor')
    parser.add_argument('--fix-only', action='store_true', help='Fix issues only, do not monitor')

    args = parser.parse_args()

    guardian = CodeGuardian(args.directory)

    if args.report_only:
        guardian._analyze_all_files()
        report_path = guardian.generate_report()
        print(f"Report generated: {report_path}")
    elif args.fix_only:
        guardian._analyze_all_files()
        print("Auto-fix completed")
    else:
        try:
            print("Code Guardian started. Press Ctrl+C to stop.")
            guardian.start_monitoring()
        except KeyboardInterrupt:
            guardian.stop_monitoring()
            report_path = guardian.generate_report()
            print(f"\nMonitoring stopped. Final report: {report_path}")

if __name__ == '__main__':
    main()